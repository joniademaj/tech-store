<?php include("../inc/header.php"); ?>

<section class="brands">
    <div class="brands-content">
        <div class="brand-logo">
            <img src="../images/apple-logo.png" alt="">
        </div>
        <div class="brand-logo">
            <img src="../images/lg-logo.png" alt="">
        </div>
        <div class="brand-logo">
            <img src="../images/sony-logo.png" alt="">
        </div>
        <div class="brand-logo">
            <img src="../images/intel-logo.png" alt="">
        </div>
        <div class="brand-logo">
            <img src="../images/nividia-logo.png" alt="">
        </div>
        <div class="brand-logo">
            <img src="../images/samsung-logo.png" alt="">
        </div>
    </div>
</section>

<?php include("../inc/footer.php"); ?>